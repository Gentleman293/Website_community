(function () {
    var reduceMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    function initCarousel(carousel) {
        var track = carousel.querySelector('.works_track');
        var prev = carousel.querySelector('.works_prev');
        var next = carousel.querySelector('.works_next');
        var dotsBox = carousel.nextElementSibling;
        if (!dotsBox || !dotsBox.classList.contains('works_dots')) dotsBox = null;
        var slides = track.querySelectorAll('.works_slide');
        var dots = [];

        // a single group: nothing to flip through
        if (slides.length < 2) {
            carousel.classList.add('is_single');
            if (dotsBox) dotsBox.hidden = true;
            return;
        }

        function currentIndex() {
            return Math.round(track.scrollLeft / track.clientWidth);
        }

        function goTo(i) {
            i = Math.max(0, Math.min(slides.length - 1, i));
            track.scrollTo({ left: i * track.clientWidth, behavior: reduceMotion ? 'auto' : 'smooth' });
        }

        function update() {
            var i = currentIndex();
            dots.forEach(function (d, k) { d.classList.toggle('is_active', k === i); });
            prev.disabled = i === 0;
            next.disabled = i === slides.length - 1;
        }

        // dots: one per group
        if (dotsBox) {
            slides.forEach(function (_, i) {
                var b = document.createElement('button');
                b.type = 'button';
                b.className = 'works_dot';
                b.setAttribute('aria-label', 'Группа ' + (i + 1));
                b.addEventListener('click', function () { goTo(i); });
                dotsBox.appendChild(b);
                dots.push(b);
            });
        }

        track.addEventListener('scroll', update, { passive: true });
        window.addEventListener('resize', function () { goTo(currentIndex()); update(); });
        prev.addEventListener('click', function () { goTo(currentIndex() - 1); });
        next.addEventListener('click', function () { goTo(currentIndex() + 1); });

        track.addEventListener('keydown', function (e) {
            if (e.key === 'ArrowLeft') { e.preventDefault(); goTo(currentIndex() - 1); }
            if (e.key === 'ArrowRight') { e.preventDefault(); goTo(currentIndex() + 1); }
        });

        update();
    }

    document.querySelectorAll('.works_carousel').forEach(initCarousel);
})();