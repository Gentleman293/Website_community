(function () {
    var KEY = 'site-theme';
    var root = document.documentElement;

    function getSaved() {
        try { return localStorage.getItem(KEY); } catch (e) { return null; }
    }
    function save(value) {
        try { localStorage.setItem(KEY, value); } catch (e) { }
    }
    function apply(theme) {
        root.setAttribute('data-theme', theme);
        var btn = document.getElementById('theme_toggle');
        if (btn) btn.setAttribute('aria-checked', theme === 'dark' ? 'true' : 'false');
    }

    apply(getSaved() === 'dark' ? 'dark' : 'light');

    document.addEventListener('DOMContentLoaded', function () {
        var btn = document.getElementById('theme_toggle');
        if (!btn) return;
        apply(root.getAttribute('data-theme'));
        btn.addEventListener('click', function () {
            var next = root.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
            apply(next);
            save(next);
        });
    });
})();